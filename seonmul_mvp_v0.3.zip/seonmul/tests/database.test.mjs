import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';
const db=new PGlite();
const J='11111111-1111-4111-8111-111111111111',M='22222222-2222-4222-8222-222222222222',X='33333333-3333-4333-8333-333333333333',A='44444444-4444-4444-8444-444444444444';
let cid,firstMessage;
async function asUser(uid,fn){await db.exec(`set role authenticated; select set_config('request.jwt.claim.sub','${uid}',false);`);try{return await fn();}finally{await db.exec('reset role');}}
async function rpc(sql,params=[]){return(await db.query(sql,params)).rows;}
before(async()=>{
 await db.exec(`create role anon;create role authenticated;create role service_role bypassrls;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;`);
 const migrationDir=new URL('../supabase/migrations/',import.meta.url);
 for(const file of (await readdir(migrationDir)).filter(f=>f.endsWith('.sql')).sort())await db.exec(await readFile(new URL(file,migrationDir),'utf8'));
 await db.query('insert into auth.users(id) values ($1),($2),($3),($4)',[J,M,X,A]);
 await db.query("update public.profiles set role='mentor' where id=$1",[M]);
 await db.query("update public.profiles set role='admin' where id=$1",[A]);
 await db.query("insert into public.mentors(user_id,display_name,accepting) values($1,'담당 선배',true)",[M]);
});
after(()=>db.close());
test('질문 저장, 동의 기록, 선배 알림을 하나의 작업으로 생성하고 재시도는 중복 생성하지 않는다',async()=>{
 const request=crypto.randomUUID();
 await asUser(M,()=>rpc("select register_device('mentor-token-1234567890','android')"));
 cid=(await asUser(J,()=>rpc('select submit_question($1,$2,$3,true,false) as id',[request,'practice','어디부터 확인할까요?'])))[0].id;
 const again=(await asUser(J,()=>rpc('select submit_question($1,$2,$3,true,false) as id',[request,'practice','어디부터 확인할까요?'])))[0].id;
 assert.equal(cid,again);
 const ms=await rpc('select * from public.consultation_messages where consultation_id=$1',[cid]);assert.equal(ms.length,1);firstMessage=ms[0].id;
 assert.equal((await rpc('select * from public.notifications where recipient_id=$1',[M])).length,1);
 assert.equal((await rpc('select * from private.notification_outbox')).length,1);
 assert.equal((await rpc("select * from public.consents where consultation_id=$1 and purpose='consultation_share'",[cid])).length,1);
});
test('동의 없는 접수, 비로그인 접근, 타인 상담 접근과 멘토 사칭을 막는다',async()=>{
 await assert.rejects(asUser(J,()=>rpc('select submit_question($1,$2,$3,false,false)',[crypto.randomUUID(),'practice','질문'])),/동의/);
 assert.equal((await asUser(X,()=>rpc('select * from public.consultations where id=$1',[cid]))).length,0);
 assert.equal((await asUser(X,()=>rpc('select * from public.consultation_messages where consultation_id=$1',[cid]))).length,0);
 await assert.rejects(asUser(X,()=>rpc('select send_consultation_message($1,$2,$3,true)',[cid,crypto.randomUUID(),'몰래 답변'])),/권한/);
 await assert.rejects(asUser(J,()=>rpc("update public.profiles set role='admin' where id=$1",[J])),/permission denied/);
 await assert.rejects(asUser(J,()=>rpc("insert into public.consultation_messages(consultation_id,author_id,author_kind,author_name,body,request_id) values($1,$2,'mentor','사칭','답변',$3)",[cid,J,crypto.randomUUID()])),/permission denied/);
 await db.exec('set role anon');try{await assert.rejects(rpc('select * from public.consultations'),/permission denied/);}finally{await db.exec('reset role');}
});
test('담당 선배가 답하면 후배 알림 생성, 미동의 상담은 노하우 후보로 만들지 않는다',async()=>{
 await asUser(J,()=>rpc("select register_device('junior-token-1234567890','ios')"));
 await asUser(M,()=>rpc('select send_consultation_message($1,$2,$3,false,$4)',[cid,crypto.randomUUID(),'마감과 받은 자료부터 같이 확인해요.','확인한 범위를 짚은 점이 좋아요.']));
 assert.equal((await rpc('select status from public.consultations where id=$1',[cid]))[0].status,'answered');
 assert.equal((await asUser(J,()=>rpc("select * from public.notifications where kind='answer'"))).length,1);
 assert.equal((await rpc('select * from public.knowledge_candidates')).length,0);
});
test('재사용 동의 후 후보 생성, 운영자 검수, 철회 시 후보 삭제',async()=>{
 await asUser(J,()=>rpc('select set_reuse_consent($1,true)',[cid]));
 const kid=(await rpc('select id from public.knowledge_candidates'))[0].id;
 await assert.rejects(asUser(M,()=>rpc('select review_knowledge($1,$2,$3,true)',[kid,'질문','답변'])),/운영자/);
 await asUser(A,()=>rpc('select review_knowledge($1,$2,$3,true)',[kid,'첫 업무의 확인 순서','마감과 자료를 먼저 정리한다.']));
 assert.equal((await rpc('select status from public.knowledge_candidates where id=$1',[kid]))[0].status,'reviewed');
 await asUser(J,()=>rpc('select set_reuse_consent($1,false)',[cid]));assert.equal((await rpc('select * from public.knowledge_candidates')).length,0);
 assert.equal((await rpc('select * from public.consultation_messages where consultation_id=$1',[cid])).length,2);
});
test('배운 점은 본인만 읽으며 타인 상담에 기록을 끼워 넣을 수 없다',async()=>{
 await asUser(J,()=>rpc('insert into public.reflections(consultation_id,user_id,body) values($1,$2,$3)',[cid,J,'마감과 받은 자료부터 확인하기']));
 assert.equal((await asUser(M,()=>rpc('select * from public.reflections'))).length,0);
 await assert.rejects(asUser(X,()=>rpc('insert into public.reflections(consultation_id,user_id,body) values($1,$2,$3)',[cid,X,'타인 기록'])),/row-level security/);
});
test('클라이언트는 푸시 작업을 실행할 수 없고, 재시도는 동일 알림을 사용한다',async()=>{
 await assert.rejects(asUser(J,()=>rpc('select * from claim_notification_jobs(10)')),/permission denied/);
 const jobs=await rpc('select * from claim_notification_jobs(10)');assert.equal(jobs.length,2);
 assert.equal((await rpc('select * from claim_notification_jobs(10)')).length,0);
 const job=jobs[0];await rpc('select finish_notification_job($1,$2,false,$3,false)',[job.job_id,job.claim_id,'network_timeout']);
 const record=(await rpc('select * from private.notification_outbox where id=$1',[job.job_id]))[0];assert.equal(record.status,'pending');assert.equal(record.attempts,1);
 await rpc('select finish_notification_job($1,$2,true)',[jobs[1].job_id,jobs[1].claim_id]);
 assert.equal((await rpc('select status from private.notification_outbox where id=$1',[jobs[1].job_id]))[0].status,'sent');
});
test('같은 기기의 다른 계정 로그인은 이전 계정의 대기 푸시를 제거한다',async()=>{
 await asUser(X,()=>rpc("select register_device('mentor-token-1234567890','android')"));
 assert.equal((await rpc('select * from private.notification_outbox o join public.device_tokens d on d.id=o.device_id where d.user_id=$1',[X])).length,0);
});
test('본인 알림만 읽음 처리하고 상대 알림은 변경할 수 없다',async()=>{
 const n=(await rpc('select * from public.notifications where recipient_id=$1',[M]))[0];
 await asUser(X,()=>rpc('update public.notifications set read_at=now() where id=$1',[n.id]));
 assert.equal((await rpc('select read_at from public.notifications where id=$1',[n.id]))[0].read_at,null);
 await asUser(M,()=>rpc('update public.notifications set read_at=now() where id=$1',[n.id]));
 assert.notEqual((await rpc('select read_at from public.notifications where id=$1',[n.id]))[0].read_at,null);
});
test('선배 권한을 회수하면 기존 배정 상담도 읽거나 답할 수 없다',async()=>{
 await rpc("update public.profiles set role='junior' where id=$1",[M]);
 assert.equal((await asUser(M,()=>rpc('select * from public.consultations'))).length,0);
 assert.equal((await asUser(M,()=>rpc('select * from public.consultation_messages'))).length,0);
 await assert.rejects(asUser(M,()=>rpc('select send_consultation_message($1,$2,$3,false)',[cid,crypto.randomUUID(),'답변'])),/권한/);
 await rpc("update public.profiles set role='mentor' where id=$1",[M]);
});
test('상담 받을 선배가 없으면 질문과 알림을 남기지 않는다',async()=>{
 await rpc('update public.mentors set accepting=false');
 const before=(await rpc('select count(*)::int n from public.consultations'))[0].n;
 await assert.rejects(asUser(X,()=>rpc('select submit_question($1,$2,$3,true,false)',[crypto.randomUUID(),'worry','고민이 있어요'])),/선배가 없습니다/);
 assert.equal((await rpc('select count(*)::int n from public.consultations'))[0].n,before);
 await rpc('update public.mentors set accepting=true');
});
test('계정 삭제는 상담, 메시지, 기록, 동의 및 연결된 알림을 함께 삭제한다',async()=>{
 await rpc('delete from auth.users where id=$1',[J]);
 for(const table of ['consultations','consultation_messages','reflections','notifications','consents']){
  const filter=table==='consultations'?'id':'consultation_id';
  assert.equal((await rpc(`select * from public.${table} where ${filter}=$1`,[cid])).length,0,table);
 }
});
