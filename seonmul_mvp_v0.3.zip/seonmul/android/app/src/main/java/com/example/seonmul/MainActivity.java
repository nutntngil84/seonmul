package com.example.seonmul;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
